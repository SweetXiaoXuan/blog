package com.blog.web.common.utils;


public class XXMediaType {
    public static final String TEXTUTF8 = "text/plain;charset=utf-8";
    public static final String FORM="\"application/xml\",\"application/json\",\"application/x-www-form-urlencoded\",  \"multipart/form-data\"";
}
